/**
 * 
 */
/**
 * 
 */
module TextAnalyzer {
}